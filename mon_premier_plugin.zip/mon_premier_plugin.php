<?php

/*
Plugin Name: Mon premier plugin !
Plugin URI: https:/www.inforaz.com/
Description: Mon prmier plugin.
Author: Couillin Yannick
Version 1.0
Author:URI: http:/www.inforaz.com/
Licence: GPLv2
*/

